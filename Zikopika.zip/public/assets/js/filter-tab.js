var light = document.getElementById('testmil');

light.addEventListener('click',function(light){
    light.target.classList.toggle('onnhigh');
});



function mybestFunction() {
    var x = document.getElementById("hisLinks");
    if (x.style.display === "none") {
      x.style.display = "block";
    } else {
      x.style.display = "none";
    }
}


var light = document.getElementById('testsecmil');

light.addEventListener('click',function(light){
    light.target.classList.toggle('onnsechigh');
});



function mygoodFunction() {
    var x = document.getElementById("hissecLinks");
    if (x.style.display === "block") {
      x.style.display = "none";
    } else {
      x.style.display = "block";
    }
}


var light = document.getElementById('testthirdmil');

light.addEventListener('click',function(light){
    light.target.classList.toggle('onnthirdhigh');
});



function mybetterFunction() {
    var x = document.getElementById("histhirdLinks");
    if (x.style.display === "block") {
      x.style.display = "none";
    } else {
      x.style.display = "block";
    }
}


var light = document.getElementById('testfouthmil');

light.addEventListener('click',function(light){
    light.target.classList.toggle('onnourthhigh');
});



function mybettersecFunction() {
    var x = document.getElementById("hisfourthLinks");
    if (x.style.display === "block") {
      x.style.display = "none";
    } else {
      x.style.display = "block";
    }
}



var light = document.getElementById('testfifthhmil');

light.addEventListener('click',function(light){
    light.target.classList.toggle('onnfifthhigh');
});



function mybetterthirdFunction() {
    var x = document.getElementById("hisfifthhLinks");
    if (x.style.display === "block") {
      x.style.display = "none";
    } else {
      x.style.display = "block";
    }
}

var light = document.getElementById('testsixmil');

light.addEventListener('click',function(light){
    light.target.classList.toggle('onnsixhigh');
});



function mybettersixFunction() {
    var x = document.getElementById("hissixLinks");
    if (x.style.display === "block") {
      x.style.display = "none";
    } else {
      x.style.display = "block";
    }
}

var light = document.getElementById('testsevenmil');

light.addEventListener('click',function(light){
    light.target.classList.toggle('onnsevenhigh');
});



function mybettersevenFunction() {
    var x = document.getElementById("hissevenLinks");
    if (x.style.display === "block") {
      x.style.display = "none";
    } else {
      x.style.display = "block";
    }
}