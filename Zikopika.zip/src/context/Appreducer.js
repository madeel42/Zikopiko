import * as AllTypes from './Types'
export const AppReducer = (state, action) => {
    switch (action.type) {
        default:
            return state
    }
}