
const Banner = () =>{
    return(
        <div className="banner-section-main-img-content-wrap mb-5">
            <div className="banner-section-main-img">
            </div>
        </div>
    )
}
export default Banner;