const Articles = () =>{
    return(

        <div className="help-promoted-articles-wrapper">
        <h1>Promoted articles</h1>
        <div className="row">
          <div className="col-sm-12 col-md-6 col-lg-4 py-3">
            <p>How do I sell an NFT?</p>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 py-3">
            <p>How do I sell an NFT?</p>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 py-3">
            <p>How do I sell an NFT?</p>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 py-3">
            <p>How do I sell an NFT?</p>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 py-3">
            <p>How do I sell an NFT?</p>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 py-3">
            <p>How do I sell an NFT?</p>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 py-3">
            <p>How do I sell an NFT?</p>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 py-3">
            <p>How do I sell an NFT?</p>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 py-3">
            <p>How do I sell an NFT?</p>
          </div>
        </div>
      </div>
    )
}
export default Articles;