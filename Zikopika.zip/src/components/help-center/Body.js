const Body = () =>{
    return(
        
      <div className="help-card-section-wrapper">
      <div className="row">
        <div className="col-sm-6 col-md-6 col-lg-4 py-3">
          <div className="help-card-outer-box">
            <h1>Getting Started</h1>
            <p> Lorem Ipsum has been the industry's standard 
              dummy text ever since the 1500s, when an 
              unknown printer took a 
            </p>
          </div>
        </div>
        <div className="col-sm-6 col-md-6 col-lg-4 py-3">
          <div className="help-card-outer-box">
            <h1>Getting Started</h1>
            <p> Lorem Ipsum has been the industry's standard 
              dummy text ever since the 1500s, when an 
              unknown printer took a 
            </p>
          </div>
        </div>
        <div className="col-sm-6 col-md-6 col-lg-4 py-3">
          <div className="help-card-outer-box">
            <h1>Getting Started</h1>
            <p> Lorem Ipsum has been the industry's standard 
              dummy text ever since the 1500s, when an 
              unknown printer took a 
            </p>
          </div>
        </div>
        <div className="col-sm-6 col-md-6 col-lg-4 py-3">
          <div className="help-card-outer-box">
            <h1>Getting Started</h1>
            <p> Lorem Ipsum has been the industry's standard 
              dummy text ever since the 1500s, when an 
              unknown printer took a 
            </p>
          </div>
        </div>
        <div className="col-sm-6 col-md-6 col-lg-4 py-3">
          <div className="help-card-outer-box">
            <h1>Getting Started</h1>
            <p> Lorem Ipsum has been the industry's standard 
              dummy text ever since the 1500s, when an 
              unknown printer took a 
            </p>
          </div>
        </div>
        <div className="col-sm-6 col-md-6 col-lg-4 py-3">
          <div className="help-card-outer-box">
            <h1>Getting Started</h1>
            <p> Lorem Ipsum has been the industry's standard 
              dummy text ever since the 1500s, when an 
              unknown printer took a 
            </p>
          </div>
        </div>
      </div>
    </div>
    )
}
export default Body;