const Banner = () =>{
    return(
        <div className="banner-section-main-img-content-wrap">
        <div className="banner-section-main-img">
          {/* <img src="assets/images/Images/6.jpg" alt=""> */}
        </div>
        <div className="banner-section-main-content">
          <img src="assets/images/Logo/Screenshot_45.png" alt="" />
          <h2>Native Mythical 
            Arts</h2>
        </div>
      </div>
    )
}
export default Banner;