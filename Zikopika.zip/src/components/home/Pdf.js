const Pdf = () =>{
    return(
    <div className="new-pdf-link-section">
        <a href="./assets/files/chipika.pdf"><b>CHIPIKA ARTWORK PDF</b></a>
    </div>
    )
}
export default Pdf;