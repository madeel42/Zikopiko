const Counter = () =>{
    return(
        <div>
        <div className="counter-sectin-wraper">
          <div className="row">
            <div className="col-6 col-sm-6 col-md-6 col-lg-3 counter-inner-box ">
              <h2>799</h2>
              <p>items</p>
            </div>
            <div className="col-6 col-sm-6 col-md-6 col-lg-3 counter-inner-box ">
              <h2>799</h2>
              <p>items</p>
            </div>
            <div className="col-6 col-sm-6 col-md-6 col-lg-3 counter-inner-box ">
              <h2> <span><img src="assets/images/SVG Icons/6f8e2979d428180222796ff4a33ab929.svg" alt="" /></span> 799</h2>
              <p>items</p>
            </div>
            <div className="col-6 col-sm-6 col-md-6 col-lg-3 counter-inner-box ">
              <h2><span><img src="assets/images/SVG Icons/6f8e2979d428180222796ff4a33ab929.svg" alt="" /></span>799</h2>
              <p>items</p>
            </div>
          </div>
        </div>
        <div className="conunter-bottom-text-section">
          <p> Lorem Ipsum has been the industry's standard dummy 
            text ever since the 1500s, when an unknown printer took a 
            galley of type and scrambled it to make</p>
        </div>
      </div>
    )
}
export default Counter;