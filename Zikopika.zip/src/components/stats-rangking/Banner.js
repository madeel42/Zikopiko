const Banner = () =>{
    
    return(
        <div className="stat-ranking-banner-title-wrapper">
        <div className="stat-ranking-banner-title">
          <h1>Top NFT's</h1>
          <p>Lorem Ipsum has been the industry's standard dummy text ever</p>
        </div>
        <div className="stat-ranking-banner-dropdownwrap pt-5">
          <div className="stat-ranking_pricing_dropdown">
            <div className="dropdown">
              <a className="btn btn-transparent" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="false" aria-expanded="false">
                <p> Single Items <span><i className="fas fa-chevron-down" /></span></p>
              </a>
              <div className="dropdown-menu" aria-labelledby="dropdownMenuLink" style={{}}>
                <a className="dropdown-item" href="#">Action</a>
                <a className="dropdown-item" href="#">Another action</a>
                <a className="dropdown-item" href="#">Something else here</a>
              </div>
            </div>
          </div>
          <div className="stat-ranking_pricing_dropdown">
            <div className="dropdown">
              <a className="btn btn-transparent" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="false" aria-expanded="false">
                <p> Single Items <span><i className="fas fa-chevron-down" /></span></p>
              </a>
              <div className="dropdown-menu" aria-labelledby="dropdownMenuLink" style={{}}>
                <a className="dropdown-item" href="#">Action</a>
                <a className="dropdown-item" href="#">Another action</a>
                <a className="dropdown-item" href="#">Something else here</a>
              </div>
            </div>
          </div>
          <div className="stat-ranking_pricing_dropdown">
            <div className="dropdown">
              <a className="btn btn-transparent" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="false" aria-expanded="false">
                <p> Single Items <span><i className="fas fa-chevron-down" /></span></p>
              </a>
              <div className="dropdown-menu" aria-labelledby="dropdownMenuLink" style={{}}>
                <a className="dropdown-item" href="#">Action</a>
                <a className="dropdown-item" href="#">Another action</a>
                <a className="dropdown-item" href="#">Something else here</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
}
export default Banner;