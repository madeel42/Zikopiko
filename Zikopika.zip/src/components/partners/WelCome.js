
const WelCome = () =>{
    return(
        <section className="welcome_nft_wrapper">
        <div className="container">
          <div className="row reverse_wrappers_responsive">
            <div className="column_medium img_content">
              <div className="content_nft">
                <h2>Welcome to the world’s largest NFT marketplace.</h2>
                <p className="content_p_nft">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making</p>
                <p className="content_p_nft">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem</p>
              </div>
              <div className="content_nft_button">
                <a href="#" role="button" className="btn btn_nft">Let's work together</a>
              </div>
            </div>
            <div className="column_medium img_content">
              <div className="content_img">
                <img src="assets/images/Illustrations/1.png" alt="" />
              </div>
            </div>
          </div>
        </div>
      </section>
    )
}
export default WelCome;