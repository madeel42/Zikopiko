
const Interested = () =>{
    return(
        <section className="interested_partnering">
            <div className="container-fluid">
                <div className="inte_partn_content">
                    <h2>Interested in partnering with us?</h2>
                    <p className="inte_partn_text">It is a long established fact that a reader will be distracted by the readable</p>
                    <a href="#" role="button" className="btn ip_button">Let's work together</a>
                </div>
            </div>
        </section>
    )
}
export default Interested;