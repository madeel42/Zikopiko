const HelpCenter = () => {
    return(
        <div className="gas-market-more-help-wrapper">
            <img src="assets/images/Illustrations/4.png" alt="" />
            <a href="#">Learn more on our help center</a>
        </div>
    )
}

export default HelpCenter;