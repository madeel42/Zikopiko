const Banner = () => {
    return(
        <div className="gas-market-banner-section">
            <div className="container">
            <div className="row pt-160 pb-100">
                <div className="col-sm-12 col-md-12 col-lg-6 order-lg-last ">
                <img src="assets/images/Illustrations/2.png" alt="" />
                </div>
                <div className="col-sm-12 col-md-12 col-lg-6 order-lg-first banner-text-wrapper">
                <h1>Imagine an NFT 
                    marketplace that's 
                    gas-free.</h1>
                <p>It is a long established fact that a reader will be distracted by the 
                    readable content of a page when looking at its layout. The point of 
                    using Lorem Ipsum is that it has a more
                </p>
                <p> It is a long established fact that a reader will be distracted by the 
                    readable content of a page when looking at its layout. The point of 
                    using Lorem</p>
                <button> Let's work together </button>
                </div>
            </div>
            </div>
      </div>
    )
}

export default Banner;