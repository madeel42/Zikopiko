import Slider from "./Slider";

const CrossBlockChain = () => {

    return(
        <div className="gas-market-place-slider-wrapper pt-160">
        <div className="container">
          <div className="gas-market-video-title-wraper">
            <h1>Cross-blockchain resources</h1>
            <p>It is a long established fact that a reader will be distracted by the readable content 
              of a page when looking at its layout. The point of using Lorem</p>
          </div>
          <Slider/>
        </div>
      </div>
    )
}

export default CrossBlockChain;