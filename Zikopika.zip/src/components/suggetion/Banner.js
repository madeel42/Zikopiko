const Banner = () => {
    
    return(
        <div className="gas-market-banner-section">
        <div className="container">
          <div className="row pt-160 pb-100">
            <div className="col-sm-12 col-md-12 col-lg-6 order-lg-last ">
              <img src="assets/images/Illustrations/5.png" alt="" />
            </div>
            <div className="col-sm-12 col-md-12 col-lg-6 order-lg-first banner-text-wrapper">
              <img src="assets/images/Logo/Screenshot_45-removebg-preview.png" alt="" />
              <p>It is a long established fact that a reader will be distracted by the 
                readable content of a page when looking at its layout. The point of 
                using Lorem Ipsum is that it has a more
              </p>
              <br />
              <p> It is a long established fact that a reader will be distracted by the 
                readable content of a page when looking at its layout. The point of 
                using Lorem</p>
            </div>
          </div>
        </div>
      </div> 
    )
}
export default Banner; 