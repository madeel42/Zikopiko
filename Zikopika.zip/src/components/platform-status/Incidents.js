
const Incidents = () =>{
    return(
        <section id="sec_3">
        <div className="container">
          <div className="row">
            <div className="col-md-8 box_4">
              <h2>Past Incidents</h2>
              {/* 1 */}
              <div className="box_5">
                <h5>Sep 30, 2021</h5>
                <p>It is a long established fact that.</p>
              </div>
              {/* 2 */}
              <div className="box_5">
                <h5>Sep 30, 2021</h5>
                <p>It is a long established fact that.</p>
              </div>
              <div className="box_5 box_6">
                <h5>Sep 30, 2021</h5>
                <div className="box_7">
                  <p>It is a long established fact that.</p>
                  {/* 1 */}
                  <div className="box_8">
                    <p>Completed</p>
                    <p>It is a long established fact that It is a long established fact that..</p>
                    <p>Sep 24, 09:30 UTC</p>
                  </div>
                  {/* 2 */}
                  <div className="box_8">
                    <p>Completed</p>
                    <p>It is a long established fact that It is a long established fact that..</p>
                    <p>Sep 24, 09:30 UTC</p>
                  </div>
                  {/* 3 */}
                  <div className="box_8">
                    <p>Completed</p>
                    <p>It is a long established fact that It is a long established fact that..</p>
                    <p>Sep 24, 09:30 UTC</p>
                  </div>
                </div>
              </div>
              {/* 4 */}
              <div className="box_5">
                <h5>Sep 30, 2021</h5>
                <p>It is a long established fact that.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    )
}
export default Incidents;