import Header2 from "../components/common/Header2"
import Banner from "../components/suggetion/Banner"
import Table from "../components/suggetion/Table"
import Footer from "../components/common/Footer"

const Suggetion = () =>{
    return(
        <>
        <Header2 />
        <Banner />
        <Table />
        <Footer />
        </>
    )
}
export default Suggetion;